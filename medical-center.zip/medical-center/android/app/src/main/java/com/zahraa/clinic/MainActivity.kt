package com.zahraa.clinic

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.net.HttpURLConnection
import java.net.URL
import android.webkit.*
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.core.content.FileProvider
import java.io.File

/** غلاف WebView يفتح برنامج المركز الطبي (نسخة PHP أو Google Apps Script) بعنوان يحدده المستخدم. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var bar: ProgressBar
    private var printWeb: WebView? = null
    private var chooserCb: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private val DEFAULT_URL = "https://clinic.wuaze.com"
    private val BASE = "https://appassets.local/"
    private val reqFile = 41
    private val reqCam = 42

    private val serverUrl get() = DEFAULT_URL

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        web = WebView(this)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8))
        setContentView(root)
        web.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        setup()
        loadApp()
    }

    /** الصفحة مضمّنة داخل التطبيق (assets) فلا تعتمد على الاستضافة؛ البيانات من خادم جوجل شيت مباشرة. */
    private fun loadApp() {
        try {
            val html = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            web.loadDataWithBaseURL(BASE, html, "text/html", "UTF-8", null)
        } catch (e: Exception) { web.loadUrl(DEFAULT_URL) }
    }

    private fun setup() {
        with(web.settings) {
            javaScriptEnabled = true
            @Suppress("DEPRECATION") saveFormData = false
            mediaPlaybackRequiresUserGesture = false
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun print() = runOnUiThread {
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print("تقرير", web.createPrintDocumentAdapter("تقرير"), PrintAttributes.Builder().build())
            }
            /** اتصال شبكي أصلي بخادم جوجل (بدون قيود CORS في المتصفح): POST ثم متابعة التحويلات بـ GET كما يفعل Apps Script. */
            @JavascriptInterface fun httpPost(id: String, url: String, body: String) {
                Thread {
                    var status = 0; var text = ""
                    try {
                        fun allowed(u: String) = Regex("^https://([a-z0-9-]+\\.)*(google\\.com|googleusercontent\\.com|githubusercontent\\.com)/").containsMatchIn(u)
                        if (!allowed(url)) throw Exception("عنوان غير مسموح")
                        var cur = url; var post = body.isNotEmpty(); var hops = 0
                        while (true) {
                            val c = URL(cur).openConnection() as HttpURLConnection
                            c.instanceFollowRedirects = false; c.connectTimeout = 20000; c.readTimeout = 60000
                            if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "text/plain;charset=utf-8"); c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) } }
                            else c.requestMethod = "GET"
                            status = c.responseCode
                            if (status in 300..399 && hops < 6) { val loc = c.getHeaderField("Location") ?: break; cur = URL(URL(cur), loc).toString(); if (!allowed(cur)) throw Exception("تحويل غير مسموح"); post = false; hops++; c.disconnect(); continue }
                            val st = if (status >= 400) c.errorStream else c.inputStream
                            text = st?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                            break
                        }
                    } catch (e: Exception) { status = 0; text = "خطأ شبكة: " + (e.message ?: e.javaClass.simpleName) }
                    runOnUiThread { web.evaluateJavascript("window.__nativeCb && window.__nativeCb(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(text) + ")", null) }
                }.start()
            }
            /** طباعة مستند HTML كامل (A4) عبر WebView مخفي — يعمل مع تقارير وشاشات البرنامج. */
            @JavascriptInterface fun printHtml(html: String, title: String, landscape: Boolean) = runOnUiThread {
                val w = WebView(this@MainActivity); printWeb = w
                w.settings.javaScriptEnabled = false
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView, u: String?) {
                        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                        val size = if (landscape) PrintAttributes.MediaSize.ISO_A4.asLandscape() else PrintAttributes.MediaSize.ISO_A4
                        pm.print(title, v.createPrintDocumentAdapter(title), PrintAttributes.Builder().setMediaSize(size).build())
                    }
                }
                w.loadDataWithBaseURL("https://appassets.local/print", html, "text/html", "UTF-8", null)
            }
            @JavascriptInterface fun btList(): String {
                if (!btAllowed()) return "[]"
                return try {
                    val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                    val arr = JSONArray(); ad?.bondedDevices?.forEach { arr.put(JSONObject().put("name", it.name ?: it.address).put("address", it.address)) }
                    arr.toString()
                } catch (e: Exception) { "[]" }
            }
            @JavascriptInterface fun btPrint(address: String, b64: String): String {
                if (!btAllowed()) return "اسمح للتطبيق باستخدام البلوتوث ثم أعد المحاولة"
                return try {
                    val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return "البلوتوث غير متاح"
                    if (!ad.isEnabled) return "شغّل البلوتوث أولاً"
                    val dev = ad.getRemoteDevice(address); ad.cancelDiscovery()
                    val sock = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                    sock.connect()
                    val data = Base64.decode(b64, Base64.DEFAULT); val os = sock.outputStream
                    var i = 0; while (i < data.size) { val n = minOf(512, data.size - i); os.write(data, i, n); os.flush(); i += n; Thread.sleep(20) }
                    Thread.sleep(600); sock.close(); "ok"
                } catch (e: Exception) { "تعذرت الطباعة: " + (e.message ?: "") }
            }
            @JavascriptInterface fun saveFile(name: String, mime: String, b64: String) = runOnUiThread {
                val dir = File(cacheDir, "exports").apply { mkdirs() }
                val f = File(dir, name.replace(Regex("[^\\w.\\- \\u0600-\\u06FF]"), "_"))
                f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                val uri = FileProvider.getUriForFile(this@MainActivity, "com.zahraa.clinic.files", f)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "حفظ / مشاركة الملف"))
            }
        }, "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val host = Uri.parse(BASE).host
                val ok = r.url.host == host || r.url.host?.endsWith("google.com") == true || r.url.host?.endsWith("googleusercontent.com") == true
                if (!ok) { startActivity(Intent(Intent.ACTION_VIEW, r.url)); return true }
                return false
            }
            override fun onPageStarted(v: WebView?, u: String?, f: Bitmap?) { bar.visibility = View.VISIBLE }
            override fun onPageFinished(v: WebView?, u: String?) { bar.visibility = View.GONE }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame && !r.url.toString().startsWith(BASE)) retryDialog("تعذر الاتصال بالخادم: ${e.description}")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) { bar.progress = p }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooserCb?.onReceiveValue(null); chooserCb = cb; pickImage(); return true
            }
        }
    }

    private fun btAllowed(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) return true
        runOnUiThread { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 43) }
        return false
    }

    override fun onResume() {
        super.onResume()
        // عند العودة للتطبيق: مزامنة فورية لتظهر أي تغييرات حدثت من الويب أو السكريبت أو مستخدم آخر
        if (::web.isInitialized) web.evaluateJavascript("window.__syncNow && window.__syncNow()", null)
    }

    private fun retryDialog(msg: String) {
        AlertDialog.Builder(this).setTitle("لا يوجد اتصال").setMessage(msg).setCancelable(false)
            .setPositiveButton("إعادة المحاولة") { _, _ -> loadApp() }
            .setNegativeButton("إغلاق", null).show()
    }

    /** اختيار صورة من المعرض أو الكاميرا (لصور البطاقات والنماذج والكارنيهات). */
    private fun pickImage() {
        val gallery = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        val extra = ArrayList<Intent>()
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            val dir = File(cacheDir, "photos").apply { mkdirs() }
            val f = File.createTempFile("cam", ".jpg", dir)
            cameraUri = FileProvider.getUriForFile(this@MainActivity, "com.zahraa.clinic.files", f)
            extra.add(Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, cameraUri))
        } else requestPermissions(arrayOf(Manifest.permission.CAMERA), reqCam)
        val chooser = Intent.createChooser(gallery, "إرفاق صورة").putExtra(Intent.EXTRA_INITIAL_INTENTS, extra.toTypedArray())
        try { startActivityForResult(chooser, reqFile) } catch (e: Exception) { chooserCb?.onReceiveValue(null); chooserCb = null }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { /* الكاميرا اختيارية: تظهر عند الإرفاق التالي */ }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(c: Int, res: Int, data: Intent?) {
        if (c != reqFile) return super.onActivityResult(c, res, data)
        val uri = if (res == RESULT_OK) (data?.data ?: cameraUri) else null
        chooserCb?.onReceiveValue(if (uri != null) arrayOf(uri) else null); chooserCb = null
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(function(){try{if(S.user&&S.screen!=='home'){back();return 1}}catch(e){}return 0})()") { r ->
            if (r != "1") super.onBackPressed()
        }
    }

}
