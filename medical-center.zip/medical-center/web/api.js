/* طبقة الاتصال: php | gas | local (تجريبي داخل المتصفح)
   نفس الأوامر تعمل في الثلاثة: status, register, login, me, logout, list, save, delete, upload, file */
(function(){
'use strict';
const MODE = window.API_MODE || 'php';
let token = null;
try { token = sessionStorage.getItem('mc_token'); } catch(e){}

/* آخر رابط خادم: يُقرأ تلقائياً من ملف server.json في المستودع (فإذا تغيّر رابط النشر يكفي تعديل الملف دون إعادة بناء التطبيق) */
const CFG_URL = 'https://raw.githubusercontent.com/asalam4a-hue/medical-system/main/medical-center/server.json';
const GAS_RE = /^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/;
let cfgDone = null;
function ensureUrl() {
  if (cfgDone) return cfgDone;
  return cfgDone = (async () => {
    const userUrl = () => { try { const u = localStorage.getItem('mc_url_user'); return u && GAS_RE.test(u) ? u : ''; } catch (e) { return ''; } };
    if (MODE === 'php' && userUrl()) { window.API_URL = userUrl(); return; }   /* رابط يحدده المستخدم له الأولوية على server.json */
    if (!window.API_URL || MODE !== 'php') return;
    try { const c = localStorage.getItem('mc_url'); if (c && GAS_RE.test(c)) window.API_URL = c; } catch (e) {}
    try {
      let txt;
      if (window.AndroidBridge && window.AndroidBridge.httpPost) {
        txt = await new Promise((ok, no) => { const id = rid(); window.__nat = window.__nat || {}; window.__nativeCb = (i, st, tx) => { const f = window.__nat[i]; if (f) { delete window.__nat[i]; f(st, tx); } }; window.__nat[id] = (st, tx) => ok(tx); setTimeout(() => no(new Error('t')), 5000); window.AndroidBridge.httpPost(id, CFG_URL + '?t=' + Date.now(), ''); });
      } else {
        const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 4000);
        txt = await (await fetch(CFG_URL + '?t=' + Date.now(), {signal: ctl.signal, cache: 'no-store'})).text(); clearTimeout(to);
      }
      const u = JSON.parse(txt).url;
      if (GAS_RE.test(u)) { window.API_URL = u; try { localStorage.setItem('mc_url', u); } catch (e) {} }
    } catch (e) {}
  })();
}
const WRITES = new Set(['bulk_save','sync_sheets','save','delete','upload','restore','reset','resetvisits','master_save','master_restore','settings_save']);
async function call(action, payload){
  const body = Object.assign({action, token, client: window.AndroidBridge ? 'الأندرويد' : 'الويب'}, payload||{});
  let res;
  if (MODE === 'gas') {
    const txt = await new Promise((ok, fail) => {
      google.script.run.withSuccessHandler(ok).withFailureHandler(e => fail(new Error((e && e.message) || String(e)))).handle(JSON.stringify(body));
    });
    res = JSON.parse(txt);
  } else if (MODE === 'local') {
    res = await Local.handle(JSON.parse(JSON.stringify(body)));
  } else {
    await ensureUrl();
    const direct = server(), isGas = /^https:\/\/script\.google(usercontent)?\.com\//.test(direct);
    const post = async (url, gas) => {
      const r = await fetch(url, {method: 'POST', redirect: 'follow', headers: {'Content-Type': gas ? 'text/plain;charset=utf-8' : 'application/json'}, body: JSON.stringify(body)});
      const t = await r.text(); let j; try { j = JSON.parse(t); } catch (e) { throw new Error('استجابة غير صالحة (' + (r.status || '') + ') — ' + (/<html|<!doctype/i.test(t) ? 'جوجل أعاد صفحة وليس بيانات: تأكد أن النشر "أي شخص" وأنه إصدار جديد' : t.slice(0, 80))); }
      if (j && j.error === 'كيان غير معروف') j.error = 'الخادم المنشور قديم ولا يعرف هذا القسم (الحجوزات) — الصق Code.gs الجديد في Google Apps Script ثم: نشر ← إدارة عمليات النشر ← ✏ ← إصدار جديد';
      if (j && j.error === 'أمر غير معروف') j.error = 'الخادم المنشور قديم ولا يدعم هذا الأمر — حدّث ملف الخادم (Code.gs في Google أو api.php في الاستضافة) ثم انشر نسخة جديدة';
      return j;
    };
    const native = !!(window.AndroidBridge && window.AndroidBridge.httpPost);
    const nativePost = url => new Promise((ok, no) => {
      const id = rid(); window.__nat = window.__nat || {};
      window.__nativeCb = (i, st, tx) => { const f = window.__nat[i]; if (f) { delete window.__nat[i]; f(st, tx); } };
      const to = setTimeout(() => { delete window.__nat[id]; no(new Error('انتهت المهلة')); }, 75000);
      window.__nat[id] = (st, tx) => { clearTimeout(to); let j; try { j = JSON.parse(tx); } catch (e) { return no(new Error('HTTP ' + st + ' — ' + (/<html|<!doctype/i.test(tx) ? 'جوجل أعاد صفحة وليس بيانات: النشر غير عام أو رابط/إصدار خاطئ' : String(tx).slice(0, 120)))); } ok(j); };
      window.AndroidBridge.httpPost(id, url, JSON.stringify(body));
    });
    if (!isGas) res = await post(direct, false);
    else {
      /* مساران إلى نفس الخادم (جوجل شيت): مباشر من المتصفح، أو عبر api.php على الاستضافة. يُحفظ المسار الذي نجح. */
      let good = ''; try { good = localStorage.getItem('mc_route') || ''; } catch (e) {}
      const routes = native ? ['native'] : (good === 'proxy' ? ['proxy', 'direct'] : ['direct', 'proxy']);
      const safeToRetry = !WRITES.has(action) || !good;
      const errs = [];
      for (const rt of routes) {
        if (errs.length && !safeToRetry) break;
        try { res = rt === 'native' ? await nativePost(direct) : rt === 'direct' ? await post(direct, true) : await post('api.php', false); try { localStorage.setItem('mc_route', rt); } catch (e) {} break; }
        catch (e) { errs.push((rt === 'native' ? 'اتصال التطبيق بجوجل' : rt === 'direct' ? 'مباشر من جوجل' : 'عبر الاستضافة') + ': ' + (e.message || e)); }
      }
      if (!res) throw new Error('تعذر الاتصال بالخادم — ' + errs.join(' | '));
      if (res.error && errs.length) res.error = /الاستضافة لا تستطيع الوصول/.test(res.error) ? 'الاستضافة المجانية تمنع الاتصال بجوجل، والاتصال المباشر من المتصفح فشل أيضاً (' + errs[0] + '). افتح رابط سكريبت جوجل مباشرة بدل رابط الاستضافة.' : res.error + ' (' + errs[0] + ')';
    }
  }
  if (res.error) { const e = new Error(res.error); e.code = res.code; throw e; }
  return res;
}
function server(){ if (window.API_URL) return window.API_URL; let u = ''; try { u = localStorage.getItem('mc_server') || ''; } catch(e){} return u || 'api.php'; }
function setServer(u){ try { u ? localStorage.setItem('mc_server', u) : localStorage.removeItem('mc_server'); } catch(e){} setToken(null); }
function setToken(t){ token = t; try { t ? sessionStorage.setItem('mc_token', t) : sessionStorage.removeItem('mc_token'); } catch(e){} }
async function diag() {
  await ensureUrl(); const out = [], body = JSON.stringify({action: 'status'}), g = window.API_URL || '';
  const one = async (name, url, gas) => { const t0 = Date.now(); try { const r = await fetch(url, {method: 'POST', redirect: 'follow', headers: {'Content-Type': gas ? 'text/plain;charset=utf-8' : 'application/json'}, body}); const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch (e) {} out.push(`${j && !j.error ? '✅' : '❌'} ${name}: HTTP ${r.status} — ${j ? (j.error || 'يعمل') : (/<html|<!doctype/i.test(t) ? 'صفحة HTML (النشر غير عام أو إصدار قديم)' : t.slice(0, 60))} (${Date.now() - t0}ms)`); } catch (e) { out.push(`❌ ${name}: ${e.message}`); } };
  if (g && window.AndroidBridge && window.AndroidBridge.httpPost) {
    const t0 = Date.now(); try { const id = rid(); const r = await new Promise((ok, no) => { window.__nat = window.__nat || {}; window.__nativeCb = (i, st, tx) => { const f = window.__nat[i]; if (f) { delete window.__nat[i]; f(st, tx); } }; window.__nat[id] = (st, tx) => ok({st, tx}); setTimeout(() => no(new Error('انتهت المهلة')), 75000); window.AndroidBridge.httpPost(id, g, body); });
      let j = null; try { j = JSON.parse(r.tx); } catch (e) {} out.push(`${j && !j.error ? '✅' : '❌'} اتصال التطبيق بجوجل: HTTP ${r.st} — ${j ? (j.error || 'يعمل') : (/<html|<!doctype/i.test(r.tx) ? 'صفحة HTML (النشر غير عام أو الرابط/الإصدار خاطئ)' : String(r.tx).slice(0, 80))} (${Date.now() - t0}ms)`); } catch (e) { out.push('❌ اتصال التطبيق بجوجل: ' + e.message); }
    return out;
  }
  if (g) await one('مباشر من المتصفح إلى جوجل', g, true);
  await one('عبر الاستضافة (api.php)', 'api.php', false);
  return out;
}
window.API = {diag, call, setToken, setServer, server, getToken: () => token, mode: MODE};

/* ====================== خادم تجريبي داخل المتصفح ====================== */
const ENT = ['users','staff','doctors','services','operations','patients','companies','visits','expenses','custody','execs','opx','opset','bookings'];
const LOOKUP = ['doctors','services','patients','companies','bookings'];
const WRITE = {staff:['staff'],doctors:['doctors'],services:['services'],operations:['operations'],patients:['patients','visits'],companies:['companies'],visits:['visits','operations'],expenses:['expenses','dues'],execs:['execs'],custody:['custody'],opx:['opx'],opset:['opset'],bookings:['bookings']};
const FIELDS = {
  users:'username,nationalId,birthDate,perms,isAdmin,active',
  staff:'code,name,nationalId,idPhoto,photo',
  doctors:'code,name,clinic,phone,nationalId,idPhoto,syndicatePhoto,photo,hireDate,percent,fixed,opPercent',
  services:'type,name,price,tax,abbr',
  operations:'date,patient,operation,clinic,doctor,doctorId,value,doctorPercent,notes,anesthetist,anesthetistId,anesthesia,deductAnes,docNo',
  patients:'name,phone',
  companies:'name,fee,contact',
  visits:'serial,date,patient,phone,clinic,doctor,doctorId,visitType,service,value,tax,category,company,docNo,formNo,formPhoto,cardNo,cardPhoto,nationalId,patientPct,discount,notes,payMethod,payRef,payPhone,birthDate,paid,operation,anesthetist,anesthetistId,anesthesia,deductAnes,doctorPercent,remTo',
  expenses:'date,category,amount,notes,doctor,dueDate,docNo',
  custody:'date,person,kind,dir,amount,notes,docNo',
  execs:'date,patient,cardNo,approvalNo,company,approvalProc,required,done,execDate,clinic,doctor',
  opx:'date,no,dept,item,center,vendor,invoiceNo,dueDate,amount,desc,status,approvedBy,approvedAt,pays,attach',
  opset:'kind,ref,name,extra,active',
  bookings:'date,kind,patient,phone,clinic,doctor,doctorId,turn,value,bpaid,notes,status'
};
const NUMS = new Set('percent,fixed,opPercent,price,tax,value,doctorPercent,fee,patientPct,discount,amount,code,serial,anesthesia,turn,bpaid'.split(','));
const DATES = new Set(['date','hireDate','birthDate','dueDate','execDate']);
const AUTO = {staff:'code', doctors:'code', visits:'serial'};

const mem = {};
const store = {
  get(k){ try { const v = localStorage.getItem(k); if (v) return JSON.parse(v); } catch(e){ if (mem[k]) return JSON.parse(mem[k]); } return null; },
  set(k, v){ const s = JSON.stringify(v); try { localStorage.setItem(k, s); } catch(e){ mem[k] = s; } }
};
const rid = () => Array.from(crypto.getRandomValues(new Uint8Array(9)), b => b.toString(16).padStart(2,'0')).join('');
async function sha(s){
  if (crypto.subtle) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return Array.from(new Uint8Array(b), x => x.toString(16).padStart(2,'0')).join(''); }
  let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) | 0; return String(h);
}
const validDate = s => { if (!/^\d{4}\/\d{2}\/\d{2}$/.test(s)) return false; const [y,m,d] = s.split('/').map(Number); const t = new Date(y, m-1, d); return t.getFullYear()===y && t.getMonth()===m-1 && t.getDate()===d; };
const has = (u, p) => u.isAdmin || (u.perms || []).includes(p);

const Local = {
  db(){ return store.get('mc_db') || {rec:{}, files:{}, tokens:{}, fails:{}}; },
  save(db){ store.set('mc_db', db); },
  async handle(b){
    const db = this.db();
    const fail = (error, code) => ({error, code});
    const A = b.action;
    if (A === 'status') return {hasUsers: (db.rec.users || []).length > 0};
    if (A === 'settings') return {settings: this.settings(db)};
    if (A === 'register') {
      const users = db.rec.users || (db.rec.users = []);
      const u = String(b.username || '').trim(), p = String(b.password || '');
      if (u.length < 3 || p.length < 4) return fail('اسم المستخدم 3 أحرف على الأقل وكلمة السر 4 أحرف على الأقل');
      if (users.some(x => x.username.toLowerCase() === u.toLowerCase())) return fail('اسم المستخدم موجود بالفعل');
      const first = users.length === 0, salt = rid();
      const rec = {id: rid(), username: u, salt, hash: await sha(salt + p), nationalId: String(b.nationalId || '').slice(0, 20), birthDate: validDate(b.birthDate) ? b.birthDate : '', perms: first ? ['*'] : [], isAdmin: first, active: first, createdAt: new Date().toISOString()};
      users.push(rec);
      if (first && window.SEED) this.seed(db);
      this.save(db);
      return {ok: true, pending: !first};
    }
    if (A === 'login') {
      const users = db.rec.users || [], u = String(b.username || '').trim().toLowerCase();
      const f = db.fails[u] || {n: 0, t: 0};
      if (f.n >= 5 && Date.now() - f.t < 600000) return fail('محاولات كثيرة، حاول بعد 10 دقائق');
      const rec = users.find(x => x.username.toLowerCase() === u);
      if (!rec || rec.hash !== await sha(rec.salt + String(b.password || ''))) { db.fails[u] = {n: f.n + 1, t: Date.now()}; this.save(db); return fail('اسم المستخدم أو كلمة السر غير صحيحة'); }
      if (!rec.active) return fail('حسابك بانتظار موافقة المدير', 'pending');
      delete db.fails[u];
      rec.lastLogin = new Date().toISOString(); rec.lastClient = String(b.client || '').slice(0, 20);
      const t = rid() + rid(); db.tokens[t] = {id: rec.id, exp: Date.now() + 12 * 3600e3}; this.save(db);
      return {token: t, user: this.pub(rec)};
    }
    const tk = db.tokens[b.token];
    const me = tk && tk.exp > Date.now() && (db.rec.users || []).find(x => x.id === tk.id && x.active);
    if (!me) return fail('انتهت الجلسة، سجل الدخول من جديد', 'auth');
    if (A === 'me') return {user: this.pub(me)};
    if (A === 'ping') { (db.presence || (db.presence = {}))[me.id] = {at: Date.now(), page: String(b.page || '').slice(0, 60), client: String(b.client || '').slice(0, 20)}; this.save(db); return {ok: true, ver: 6}; }
    if (A === 'presence') { if (!me.isAdmin) return fail('للمدير فقط', 'forbidden'); return {list: Object.entries(db.presence || {}).map(([id, v]) => Object.assign({id}, v))}; }
    if (A === 'logout') { delete db.tokens[b.token]; this.save(db); return {ok: true}; }
    if (['settings_save','backup','restore','reset','resetvisits','master_save','master_restore','master_info'].includes(A)) {
      if (!me.isAdmin) return fail('للمدير فقط', 'forbidden');
      const snap = () => { const d = {}; ENT.forEach(x => d[x] = JSON.parse(JSON.stringify(db.rec[x] || []))); return {app: 'medical-center', ver: 1, at: new Date().toISOString(), settings: this.settings(db), data: d}; };
      const restore = bk => {
        if (!bk || bk.app !== 'medical-center' || !bk.data) return 'ملف النسخة الاحتياطية غير صالح';
        if (!(bk.data.users || []).some(u => u.isAdmin && u.active)) return 'النسخة لا تحتوي على مدير فعّال';
        ENT.forEach(x => { db.rec[x] = Array.isArray(bk.data[x]) ? bk.data[x] : []; });
        if (bk.settings) db.settings = bk.settings; this.save(db); return '';
      };
      if (A === 'settings_save') { db.settings = {appName: String(b.appName || '').trim().slice(0, 80), centerName: String(b.centerName || '').trim().slice(0, 80), phone: String(b.phone || '').trim().slice(0, 60), logo: db.files[b.logo] ? String(b.logo) : '', azkAudio: String(b.azkAudio || '').split(',').filter(x => db.files[x]).slice(0, 10).join(',')}; this.save(db); return {settings: this.settings(db)}; }
      if (A === 'backup') return {backup: snap()};
      if (A === 'master_info') return {at: db.master ? db.master.at : ''};
      if (A === 'master_save') { db.master = snap(); this.save(db); return {at: db.master.at}; }
      if (A === 'master_restore') { if (!db.master) return fail('لا توجد نسخة ماستر محفوظة'); const m = JSON.parse(JSON.stringify(db.master)), er = restore(m); return er ? fail(er) : {ok: true}; }
      if (A === 'restore') { const er = restore(b.backup); return er ? fail(er) : {ok: true}; }
      if (A === 'resetvisits') { if (!me.isAdmin) return fail('للمدير فقط'); db.rec.visits = []; db.ctr = db.ctr || {}; db.ctr.visits = 0; this.save(db); return {ok: true}; }
      if (A === 'reset') { if (String(b.confirm || '') !== 'حذف الكل') return fail('اكتب عبارة التأكيد: حذف الكل'); db.ctr = db.ctr || {}; db.ctr.visits = 0; ['patients','operations','visits','expenses','custody','execs','opx'].forEach(x => { db.rec[x] = []; }); this.save(db); return {ok: true}; }
    }
    const e = b.entity;
    if (A === 'sync_sheets') return me.isAdmin ? {ok: true, counts: {}} : fail('للمدير فقط', 'forbidden');
    if (A === 'bulk_save') {
      if (!me.isAdmin) return fail('للمدير فقط', 'forbidden'); if (e === 'users' || !ENT.includes(e)) return fail('كيان غير مسموح');
      const list = db.rec[e] || (db.rec[e] = []), kf = String(b.key || '').split(',').filter(Boolean), kk = r => kf.map(k => String(r[k] == null ? '' : r[k])).join('|'), seen = new Set(kf.length ? list.map(kk) : []); let added = 0, skipped = 0, ctr = AUTO[e] ? list.reduce((m, x) => Math.max(m, x[AUTO[e]] || 0), 0) : 0;
      for (const src of (b.records || [])) { const out = {}; for (const k of FIELDS[e].split(',')) { if (!(k in src)) continue; let v = src[k]; if (NUMS.has(k)) v = Number(v) || 0; else v = String(v == null ? '' : v).trim().slice(0, 500); out[k] = v; }
        if (!String(out.name || out.date || out.category || out.type || '').trim()) { skipped++; continue; } if (kf.length) { const key = kk(out); if (seen.has(key)) { skipped++; continue; } seen.add(key); } if (AUTO[e]) out[AUTO[e]] = ++ctr; list.push(Object.assign({id: rid(), createdAt: new Date().toISOString(), registeredBy: me.username}, out)); added++; }
      this.save(db); return {added, skipped};
    }
    if (['list','save','delete'].includes(A) && !ENT.includes(e)) return fail('كيان غير معروف');
    if (A === 'listall') { const all = {}; for (const en of (Array.isArray(b.entities) ? b.entities : [])) { if (!ENT.includes(en)) continue; const r = await this.handle(Object.assign({}, b, {entity: en, action: 'list'})); all[en] = r && r.items ? r : {items: [], err: (r && r.error) || ''}; } return {all}; }
    if (A === 'list') {
      const readable = me.isAdmin || (e !== 'users' && (e === 'staff' ? has(me, 'staff') : (LOOKUP.includes(e) || has(me, e) || has(me, 'dashboard') || has(me, 'dues') || me.perms.some(p => p.startsWith('rep_')))));
      if (!readable) return fail('غير مصرح', 'forbidden');
      let items = (db.rec[e] || []).slice();
      if (b.from) items = items.filter(r => !r.date || r.date >= b.from);
      if (b.to) items = items.filter(r => !r.date || r.date <= b.to);
      return {items: items.map(r => e === 'users' ? this.pub(r) : r), ctr: AUTO[e] ? Math.max((db.ctr || {})[e] || 0, (db.rec[e] || []).reduce((m, x) => Math.max(m, x[AUTO[e]] || 0), 0)) : undefined};
    }
    if (A === 'save' || A === 'delete') {
      const ok = me.isAdmin || (e !== 'users' && (WRITE[e] || []).some(p => has(me, p)));
      if (!ok) return fail('غير مصرح', 'forbidden');
      const list = db.rec[e] || (db.rec[e] = []);
      if (A === 'delete') {
        const r = list.find(x => x.id === b.id); if (!r) return fail('غير موجود');
        if (e === 'users' && (r.id === me.id || (r.isAdmin && list.filter(x => x.isAdmin && x.active).length < 2))) return fail('لا يمكن حذف هذا المستخدم');
        db.rec[e] = list.filter(x => x.id !== b.id); this.save(db); return {ok: true};
      }
      const src = b.record || {}, out = {};
      for (const k of FIELDS[e].split(',')) {
        if (!(k in src)) continue; let v = src[k];
        if (k === 'perms') v = Array.isArray(v) ? v.map(String).slice(0, 60) : [];
        else if (k === 'isAdmin' || k === 'active') v = !!v;
        else if (NUMS.has(k)) v = Number(v) || 0;
        else { v = String(v == null ? '' : v).trim().slice(0, 500); if (DATES.has(k) && v && !validDate(v)) return fail('صيغة التاريخ يجب أن تكون yyyy/mm/dd'); }
        out[k] = v;
      }
      let rec = src.id && list.find(x => x.id === src.id);
      if (e === 'users') {
        const nm = String(out.username || '').trim();
        if (nm.length < 3) return fail('اسم المستخدم قصير');
        if (list.some(x => x.id !== src.id && x.username.toLowerCase() === nm.toLowerCase())) return fail('اسم المستخدم موجود بالفعل');
        if (!rec && String(src.password || '').length < 4) return fail('كلمة السر 4 أحرف على الأقل');
        if (rec && (rec.isAdmin && (!out.isAdmin || !out.active)) && list.filter(x => x.isAdmin && x.active).length < 2) return fail('يجب بقاء مدير واحد على الأقل');
        if (src.password) { out.salt = rid(); out.hash = await sha(out.salt + src.password); }
      } else {
        if (!String(out.name || out.date || out.category || out.type || '').trim()) return fail('بيانات ناقصة');
        if (e === 'visits') out.serial = (rec && rec.date === out.date) ? (rec.serial || 0) : list.reduce((m, x) => x.date === out.date ? Math.max(m, +x.serial || 0) : m, 0) + 1;
        else if (e !== 'users' && AUTO[e] && !rec) { db.ctr = db.ctr || {}; out[AUTO[e]] = db.ctr[e] = Math.max(db.ctr[e] || 0, list.reduce((m, x) => Math.max(m, x[AUTO[e]] || 0), 0)) + 1; }
        if (rec && AUTO[e] && e !== 'visits') out[AUTO[e]] = rec[AUTO[e]];
      }
      if (rec) Object.assign(rec, out, {updatedAt: new Date().toISOString()});
      else { rec = Object.assign({id: rid(), createdAt: new Date().toISOString()}, out); if (e === 'visits' || e === 'expenses' || e === 'custody') rec.registeredBy = me.username; list.push(rec); }
      this.save(db);
      return {record: e === 'users' ? this.pub(rec) : rec};
    }
    if (A === 'upload') {
      const AUDIO = ['audio/mpeg','audio/mp3','audio/mp4','audio/x-m4a','audio/aac','audio/ogg','audio/wav','audio/webm'];
      if (!['image/jpeg','image/png','image/webp'].concat(AUDIO).includes(b.mime)) return fail('نوع الملف غير مسموح');
      if (String(b.data || '').length > (AUDIO.includes(b.mime) ? 32e6 : 5.5e6)) return fail('الملف كبير جداً');
      const id = rid(); db.files[id] = 'data:' + b.mime + ';base64,' + b.data; this.save(db); return {file: id};
    }
    if (A === 'file') { const d = db.files[b.id]; return d ? {dataUrl: d} : fail('الملف غير موجود'); }
    return fail('أمر غير معروف');
  },
  settings(db){ return Object.assign({appName: 'برنامج إدارة المركز الطبي', centerName: '', phone: '', logo: '', azkAudio: ''}, db.settings || {}); },
  pub(r){ const o = Object.assign({}, r); delete o.hash; delete o.salt; return o; },
  seed(db){
    const S = window.SEED, mk = (e, a) => { const list = db.rec[e] || (db.rec[e] = []); a.forEach(x => list.push(Object.assign({id: rid(), createdAt: new Date().toISOString()}, x, AUTO[e] ? {[AUTO[e]]: list.length + 1} : {}))); };
    mk('services', S.services); mk('doctors', S.doctors); mk('companies', S.companies); mk('staff', S.staff);
  }
};
})();
