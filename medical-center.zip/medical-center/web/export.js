/* ============ التصدير: Excel (xlsx حقيقي بدون مكتبات) و PDF (عبر نافذة الطباعة: حفظ كـ PDF) ============ */
'use strict';
(function () {
  const enc = new TextEncoder();
  const crcT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = crcT[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zip(files) { // تخزين بدون ضغط
    const parts = [], cen = []; let off = 0;
    for (const [name, text] of files) {
      const nb = enc.encode(name), d = enc.encode(text), c = crc32(d);
      const lh = new DataView(new ArrayBuffer(30)); lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true); lh.setUint32(14, c, true); lh.setUint32(18, d.length, true); lh.setUint32(22, d.length, true); lh.setUint16(26, nb.length, true);
      parts.push(new Uint8Array(lh.buffer), nb, d);
      const ch = new DataView(new ArrayBuffer(46)); ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint32(16, c, true); ch.setUint32(20, d.length, true); ch.setUint32(24, d.length, true); ch.setUint16(28, nb.length, true); ch.setUint32(42, off, true);
      cen.push(new Uint8Array(ch.buffer), nb); off += 30 + nb.length + d.length;
    }
    const csz = cen.reduce((s, x) => s + x.length, 0), end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, csz, true); end.setUint32(16, off, true);
    return new Blob([...parts, ...cen, new Uint8Array(end.buffer)], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  }
  const xe = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const colName = i => { let s = ''; for (i++; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + (i - 1) % 26) + s; return s; };
  const toNum = t => { if (typeof t === 'number') return t; if (!/^-?(\d{1,3}(,\d{3})+|\d+)(\.\d+)?$/.test(t)) return null; if (!/[.,]/.test(t) && (t[0] === '0' && t.length > 1 || t.length > 9)) return null; return parseFloat(t.replace(/,/g, '')); };

  function sheetXML(rows, headRows) {
    const widths = []; rows.forEach(r => r.forEach((c, i) => { widths[i] = Math.min(45, Math.max(widths[i] || 8, String(c).length * 1.5 + 3)); }));
    let x = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="${headRows}" topLeftCell="A${headRows + 1}" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>`;
    rows.forEach((r, ri) => {
      x += `<row r="${ri + 1}">`;
      r.forEach((c, ci) => {
        const ref = colName(ci) + (ri + 1), head = ri < headRows, n = head ? null : toNum(c);
        if (n !== null) x += `<c r="${ref}" s="2"><v>${n}</v></c>`; else x += `<c r="${ref}" s="${head ? 1 : 0}" t="inlineStr"><is><t xml:space="preserve">${xe(c)}</t></is></c>`;
      });
      x += '</row>';
    });
    return x + '</sheetData></worksheet>';
  }
  function xlsx(sheets) { // sheets: [{name, rows:[[...]], headRows}]
    const used = new Set(), names = sheets.map((s, i) => { let n = String(s.name || 'ورقة' + (i + 1)).replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 28) || 'ورقة' + (i + 1); let m = n, k = 2; while (used.has(m)) m = n.slice(0, 25) + ' ' + k++; used.add(m); return m; });
    const files = [
      ['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`],
      ['_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
      ['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${xe(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`],
      ['xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`],
      ['xl/styles.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="12"/><name val="Times New Roman"/></font><font><b/><sz val="12"/><name val="Times New Roman"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFBFEFE8"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="right"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="right"/></xf><xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="right"/></xf></cellXfs></styleSheet>`]
    ];
    sheets.forEach((s, i) => files.push([`xl/worksheets/sheet${i + 1}.xml`, sheetXML(s.rows, s.headRows || 1)]));
    return zip(files);
  }

  /* ---------- قراءة الجداول الظاهرة على الشاشة ---------- */
  function domSheets(root, title) {
    const out = [];
    $$('table', root).forEach((t, i) => {
      const heads = $$('thead th', t).map(th => th.textContent.replace(/\s+/g, ' ').trim()), keep = heads.map(h => h !== '');
      const pick = cells => cells.filter((_, j) => keep[j]);
      const rows = [pick(heads)];
      $$('tbody tr', t).forEach(tr => { const tds = $$('td', tr); if (tds.length === 1 && tds[0].classList.contains('empty')) return; rows.push(pick(tds.map(td => { const tx = td.textContent.replace(/\s+/g, ' ').trim(); return !tx && td.querySelector('img,[data-fid]') ? 'مرفق' : tx; }))); });
      $$('tfoot tr', t).forEach(tr => rows.push(pick($$('td', tr).map(td => td.textContent.replace(/\s+/g, ' ').trim()))));
      if (rows.length < 2 && !$('tfoot', t)) return;
      let nm = title, p = t.closest('.tbl-wrap') || t, prev = p.previousElementSibling;
      while (prev && !prev.classList.contains('sect')) prev = prev.previousElementSibling;
      if (prev) nm = prev.textContent.trim(); else if (i > 0) nm = title + ' ' + (i + 1);
      out.push({name: nm, rows});
    });
    return out;
  }
  const pageTitle = () => (($('#main h1') || {}).textContent || 'تقرير').replace(/\s+/g, ' ').trim();
  const stamp = () => today().replace(/\//g, '-');

  function saveBlob(blob, name) {
    if (window.AndroidBridge && window.AndroidBridge.saveFile) {
      const fr = new FileReader(); fr.onload = () => window.AndroidBridge.saveFile(name, blob.type, String(fr.result).split(',')[1]); fr.readAsDataURL(blob); return;
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  }
  window.saveBlob = saveBlob;
  Acts.xlsx = () => {
    const title = pageTitle().replace(/^[^؀-ۿA-Za-z0-9]+/, '');
    let sheets = S.view && S.view.exportData ? S.view.exportData() : domSheets($('#main'), title.slice(0, 24));
    if (!sheets.length) return toast('لا توجد بيانات للتصدير', true);
    const meta = [[CENTER], ...(CPHONE ? [['هاتف: ' + CPHONE]] : []), [title], [S.view && S.view.noRange ? '' : rangeLabel()], ['تاريخ التصدير: ' + today() + ' — ' + (S.user ? S.user.username : '')], []];
    sheets = sheets.map(s => ({name: s.name, rows: [...meta.map(r => r.slice()), ...s.rows], headRows: meta.length + 1}));
    saveBlob(xlsx(sheets), `${title.replace(/[\\/:*?"<>|]/g, ' ').trim()}-${stamp()}.xlsx`); toast('تم تجهيز ملف Excel');
  };
  /* ---- الطباعة: التقرير المطلوب فقط على A4 — العنوان أعلى الصفحة، مربع الإجمالي على اليسار، ثم مربع التفاصيل (يتوسّط الصفحة ويتقلّص ليحتوي كل البيانات) ---- */
  const PRINT_CSS = (land) => { const W = land ? 281 : 194; return `@page{size:A4 ${land ? 'landscape' : 'portrait'};margin:8mm}*{box-sizing:border-box;font-family:"Times New Roman",Times,serif;color:#000;-webkit-print-color-adjust:exact;print-color-adjust:exact}
html,body{margin:0;background:#fff;direction:rtl;font-size:12px}.page{width:${W}mm;margin:0 auto;padding:0}
.hd{position:relative;text-align:center;border-bottom:2px solid #000;padding:2px 0 6px;margin-bottom:8px;min-height:46px}.hd h2{margin:0;padding:6px 110px 0;font-size:20px;line-height:1.35}.hd .tot{position:absolute;left:0;top:0;border:2px solid #000;padding:3px 12px;text-align:center;min-width:100px}.hd .tot small{display:block;font-size:10px}.hd .tot b{font-size:15px}
.box{border:1.5px solid #000;border-radius:3px;padding:6px}.charts{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0}.panel{border:1px solid #000;border-radius:3px;padding:5px;break-inside:avoid}.panel h3{margin:0 0 4px;font-size:12px;text-align:center}.barrow{display:grid;grid-template-columns:30% 1fr 20%;gap:5px;align-items:center;margin:3px 0;font-size:10px}.barrow .tr{height:10px;background:#ddd;border:1px solid #777}.barrow .tr i{display:block;height:100%;background:#444!important;box-shadow:none!important}.legend{display:flex;flex-wrap:wrap;gap:3px 10px;font-size:10px;margin-top:4px}.legend i{display:inline-block;width:10px;height:10px;border:1px solid #000;margin-inline-end:3px}.pb{page-break-before:always}
table{width:100%;border-collapse:collapse;margin:6px 0;page-break-inside:auto;table-layout:auto}tr{page-break-inside:avoid}th,td{border:1px solid #000;padding:3px 5px;text-align:center;font-size:11px;vertical-align:middle;white-space:nowrap}th{background:#e9e9e9}tfoot td{font-weight:bold;background:#f3f3f3}
.sect h2,h2.s{font-size:14px;margin:10px 0 2px;border-right:4px solid #000;padding-right:6px}.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:5px;margin:6px 0}.kpi{border:1px solid #000;padding:4px;text-align:center;border-radius:4px}.kpi *{font-size:11px}
img{max-height:28px}svg{max-width:100%;height:auto}.slip td:first-child{width:32%;font-weight:bold;background:#f3f3f3}.slip td{text-align:right;font-size:13px;padding:5px 8px}.sign{display:flex;justify-content:space-between;margin-top:34px;font-size:12px}
@media screen{body{background:#8a8a8a}.page{background:#fff;margin:8px auto;padding:8mm;width:${W + 16}mm;box-shadow:0 0 6px #000}}`; };
  const FIT_JS = `<script>(function(){function fit(){var t=document.getElementById('fit'),b=t&&t.parentNode;if(!t||!b)return;t.style.zoom=1;var w=b.clientWidth-14,sw=t.scrollWidth;if(sw>w+1)t.style.zoom=Math.max(.3,w/sw*.985)}window.addEventListener('load',fit);window.addEventListener('beforeprint',fit);setTimeout(fit,150)})()<\/script>`;
  const hdr = (title, sub, total) => `<div class="hd">${total ? `<div class="tot"><small>إجمالي القيمة</small><b>${esc(total)}</b></div>` : ''}<h2>${esc(title)}</h2></div>`;
  function previewPrint(doc, title) {
    const old = document.getElementById('pvov'); if (old) old.remove();
    const ov = document.createElement('div'); ov.id = 'pvov'; ov.className = 'noprint';
    ov.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#555;display:flex;flex-direction:column;direction:rtl';
    ov.innerHTML = `<div style="display:flex;gap:8px;align-items:center;padding:8px;background:#fff;border-bottom:1px solid #999;flex-wrap:wrap"><b style="flex:1;min-width:120px;font-size:14px">${esc(title)}</b><button class="btn c-teal" id="pvp">🖨️ طباعة / PDF</button><button class="btn c-red" id="pvc">✖ إغلاق</button></div><iframe id="pvf" style="flex:1;border:0;width:100%;background:#8a8a8a"></iframe>`;
    document.body.appendChild(ov);
    const fr = ov.querySelector('#pvf'), go = () => { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (e) { toast('تعذرت الطباعة من هنا — جرّب من متصفح الهاتف/الكمبيوتر مباشرة', true); } };
    ov.querySelector('#pvp').onclick = go; ov.querySelector('#pvc').onclick = () => ov.remove();
    fr.srcdoc = doc; fr.onload = () => setTimeout(go, 400);
  }
  function printDoc(title, sub, bodyHTML, land, opt) {
    const custom = !!(opt && opt.css), foot = '';
    const inner = custom ? bodyHTML : `<div class="box"><div id="fit">${bodyHTML}</div></div>${foot}`;
    const doc = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(title)}</title><style>${custom ? opt.css : PRINT_CSS(land)}</style></head><body><div class="page">${opt && opt.head != null ? opt.head : hdr(title, sub, opt && opt.total)}${inner}</div>${custom ? '' : FIT_JS}</body></html>`;
    if (window.AndroidBridge && window.AndroidBridge.printHtml) { window.AndroidBridge.printHtml(doc, title, !!land); return; }
    if (window.AndroidBridge) { // الأندرويد (نسخة قديمة): نستبدل المحتوى مؤقتاً
      const root = $('#app'), keep = root.innerHTML, st = document.createElement('style'); st.textContent = (custom ? opt.css : PRINT_CSS(land)).replace(/\*\{[^}]*\}/, ''); document.head.appendChild(st);
      root.innerHTML = `<div class="page">${opt && opt.head != null ? opt.head : hdr(title, sub, opt && opt.total)}${inner}</div>`;
      let done = false; const back = () => { if (done) return; done = true; st.remove(); root.innerHTML = keep; render(); };
      window.AndroidBridge.print(); setTimeout(back, 4000); return;
    }
    previewPrint(doc, title);
  }
  window.printDoc = printDoc;
  function cleanContent() {
    const m = $('#main').cloneNode(true);
    m.querySelectorAll('.pagehead,form,.bar,.noprint,.cards,.modal,input,select,textarea,script,.imgfld,[data-rangebar]').forEach(n => n.remove());
    m.querySelectorAll('.printhead').forEach(n => n.remove());
    m.querySelectorAll('button').forEach(bt => { if (bt.classList.contains('btn') || bt.dataset.act === 'kpi') bt.remove(); else bt.replaceWith(document.createTextNode(bt.textContent)); });
    m.querySelectorAll('table').forEach(t => { // حذف عمود الأزرار (رأس فارغ)
      const ths = [...t.querySelectorAll('thead th')]; ths.forEach((th, i) => { if (!th.textContent.trim()) { t.querySelectorAll('tr').forEach(r => { const c = r.children[i]; if (c && (c.tagName === 'TH' || !c.textContent.trim() || r.closest('tfoot'))) c.remove(); }); } });
    });
    m.querySelectorAll('table').forEach(t => { const ths = [...t.querySelectorAll('thead th')]; for (let i = ths.length - 1; i >= 0; i--) if (/^\s*(صور[ةه]|سجّ?لها|سجله|مسئول التسجيل|مسؤول التسجيل|المسجِّل)/.test(ths[i].textContent)) t.querySelectorAll('thead tr, tbody tr, tfoot tr').forEach(r => { if (r.children[i] && r.children[i].colSpan <= 1) r.children[i].remove(); }); });
    m.querySelectorAll('table').forEach(t => { const h0 = t.querySelector('thead th'); if (h0 && /^\s*(م|#)\s*$/.test(h0.textContent)) [...t.querySelectorAll('tbody tr')].filter(r => !r.querySelector('td.empty')).forEach((r, i) => { if (r.children[0]) r.children[0].textContent = i + 1; }); });
    m.querySelectorAll('.tbl-wrap').forEach(w => { w.style.overflow = 'visible'; });
    const kp = [...m.querySelectorAll('.kpis')]; if (kp.length && m.querySelector('table')) { kp.forEach(n => n.remove()); const w = document.createElement('div'); w.innerHTML = '<h2 class="s">ملخص</h2>' + kp.map(n => n.outerHTML).join(''); m.appendChild(w); } // العنوان ثم الجدول أولاً، والملخص بعده
    const land = [...m.querySelectorAll('table')].some(t => (t.querySelector('tr') || {children: []}).children.length > 7);
    return {html: m.innerHTML, land};
  }
  Acts.pdf = () => {
    let {html, land} = cleanContent(); const title = pageTitle().replace(/^[^؀-ۿA-Za-z0-9]+/, '');
    if (S.view && S.view.printHTML) { html = S.view.printHTML(); land = !!S.view.printLand; }
    let total = ''; try { total = S.view && S.view.total ? S.view.total() : ''; } catch (e) {}
    if (!total && !(S.view && S.view.noTotal)) { const ks = [...$('#main').querySelectorAll('.kpi[data-l]')]; const k = ks.find(x => /إجمالي/.test(x.dataset.l)) || ks.find(x => /صافي/.test(x.dataset.l)); if (k) total = k.dataset.v; }
    if (!total && !(S.view && S.view.noTotal)) { const tf = $('#main tfoot tr:last-child'); if (tf) { const c = [...tf.children].map(x => x.textContent.trim()).filter(x => /^-?[\d,.]+$/.test(x)); if (c.length) total = c[c.length - 1]; } }
    const sub = `${S.view && S.view.noRange ? '' : rangeLabel()} — طُبع في ${today()} بواسطة ${S.user ? S.user.username : ''}`;
    let box = document.createElement('div'); box.innerHTML = html; const flat = n => [...n.children].flatMap(c => c.tagName === 'DIV' && !c.className ? flat(c) : [c]); const units = []; let curU = null;
    flat(box).forEach(n => { if (n.classList.contains('sect') || n.matches('h2.s')) { curU = {name: n.textContent.trim() || 'بند', nodes: [n]}; units.push(curU); } else if (curU) curU.nodes.push(n); else { curU = {name: 'العنوان / الملخص', nodes: [n]}; units.push(curU); } });
    if (units.length < 3) return printDoc(title, sub, html, land, {total});
    const m = modal(`<h3>🖨️ اختر البنود المراد طباعتها</h3><div class="perm-grid">${units.map((u, i) => `<label><input type="checkbox" class="pu" data-i="${i}" checked> ${esc(u.name)}</label>`).join('')}</div><div class="actions"><button class="btn c-teal" id="pgo">🖨️ طباعة المحدد</button><button class="btn ghost" id="pcl">إلغاء</button></div>`);
    $('#pcl', m).onclick = () => m.remove();
    $('#pgo', m).onclick = () => { const keep = $$('.pu', m).filter(c => c.checked).map(c => +c.dataset.i); if (!keep.length) return toast('اختر بنداً واحداً على الأقل', true); m.remove(); const out = document.createElement('div'); keep.forEach(i => units[i].nodes.forEach(n => out.appendChild(n.cloneNode(true)))); printDoc(title, sub, out.innerHTML, land, {total}); };
  };
  /* طباعة بند واحد (إيصال/بطاقة) من أي شاشة إدخال */
  Acts.prow = el => {
    const cfg = (window.CRUDS || {})[el.dataset.e], r = cfg && S.data[cfg.ent].find(x => x.id === el.dataset.id); if (!r) return;
    const rows = cfg.fields.filter(f => f.l && !['html', 'img'].includes(f.t) && !f.k.startsWith('_') || f.k === '_doc').map(f => {
      let v = f.k === '_doc' ? r.doctor : r[f.k]; if (v == null || v === '') return ''; if (f.t === 'chk') v = v ? 'نعم' : 'لا'; if (f.t === 'seg') { const o = f.opts.find(x => x.v === v); v = o ? o.l : v; }
      return `<tr><td>${esc(f.l)}</td><td>${esc(v)}</td></tr>`;
    }).join('');
    const extra = r.registeredBy ? `<tr><td>سجّله</td><td>${esc(r.registeredBy)}</td></tr>` : ''; const bcRow = cfg.ent === 'visits' && visitCode(r) ? `<tr><td>الباركود</td><td style="text-align:center">${barcodeSVG(visitCode(r), 40)}<div style="font-family:monospace;letter-spacing:2px">${visitCode(r)}</div></td></tr>` : '';
    printDoc(cfg.t.replace(/\s*\(.*\)/, '') + (r.serial ? ` — رقم ${r.serial}` : ''), `طُبع في ${today()} بواسطة ${S.user ? S.user.username : ''}`, `<table class="slip"><tbody>${rows}${extra}${bcRow}</tbody></table><div class="sign"><span>توقيع المسؤول: ........................</span><span>توقيع المستلم: ........................</span></div>`, false);
  };
  /* ---- إيصال كاشير صغير: معاينة + طباعة عادية + طباعة بلوتوث (ESC/POS صورة) ---- */
  const PAYL = {cash: 'نقدي', visa: 'فيزا', master: 'ماستر كارد', transfer: 'تحويل كاش', credit: 'دفع آجل'};
  const receiptLines = r => {
    const L = [['c', CENTER, 'b'], CPHONE ? ['c', '☎ ' + CPHONE] : null, ['hr'], ['c', 'إيصال استلام نقدية' + (r.serial ? ' — رقم ' + r.serial : ''), 'b'], ['c', r.date], ['hr'],
      ['kv', 'اسم المريض', r.patient], ['kv', 'نوع الزيارة', r.visitType || ''], ['kv', 'طريقة الدفع', (PAYL[r.payMethod] || 'نقدي') + (r.payRef ? ' (' + r.payRef + ')' : '')], ['hr'],
      ['kv', 'القيمة', fmtN(+r.value || 0), 'big'], ['hr'], ...(visitCode(r) ? [['bc', visitCode(r)], ['c', visitCode(r)], ['hr']] : []), ['c', 'شكراً لزيارتكم'], ['c', 'وندعو لكم بالشفاء العاجل']];
    return L.filter(Boolean);
  };
  async function receiptCanvas(r, w) {
    const c = document.createElement('canvas'), pad = 10, lh = 30; c.width = w; const lines = receiptLines(r);
    let logoImg = null; const src = CLOGO; if (src) { logoImg = await new Promise(ok => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ok(null); i.src = src; }); }
    c.height = lines.length * (lh + 6) + (logoImg ? 70 : 0) + 40 + (lines.some(l => l[0] === 'bc') ? 50 : 0);
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = '#000'; x.direction = 'rtl'; x.textBaseline = 'middle';
    let y = 8; if (logoImg) { const k = Math.min(60 / logoImg.height, 200 / logoImg.width); x.drawImage(logoImg, (w - logoImg.width * k) / 2, y, logoImg.width * k, logoImg.height * k); y += 66; }
    lines.forEach(l => {
      const t = l[0]; y += (lh + 6) / 2;
      if (t === 'hr') { x.setLineDash([4, 3]); x.beginPath(); x.moveTo(pad, y); x.lineTo(w - pad, y); x.stroke(); x.setLineDash([]); }
      else if (t === 'bc') { const bits = code128Bits(l[1]), m = Math.max(1, Math.floor((w - 2 * pad) / (bits.length + 20))), x0 = (w - bits.length * m) / 2; for (let i = 0; i < bits.length; i++) if (bits[i] === '1') x.fillRect(x0 + i * m, y - 14, m, 70); y += 50; }
      else if (t === 'c') { x.font = (l[2] === 'b' ? 'bold ' : '') + '22px "Times New Roman",serif'; x.textAlign = 'center'; x.fillText(l[1], w / 2, y); }
      else { x.font = (l[3] === 'big' ? 'bold 28px' : '22px') + ' "Times New Roman",serif'; x.textAlign = 'right'; x.fillText(l[1], w - pad, y); x.textAlign = 'left'; x.font = 'bold ' + (l[3] === 'big' ? 28 : 22) + 'px "Times New Roman",serif'; x.fillText(l[2], pad, y); }
      y += (lh + 6) / 2;
    });
    return c;
  }
  /* تحويل الصورة إلى أوامر ESC/POS (GS v 0) */
  function escposBytes(c) {
    const w = c.width, h = c.height, d = c.getContext('2d').getImageData(0, 0, w, h).data, bw = Math.ceil(w / 8), out = [0x1B, 0x40, 0x1B, 0x61, 1];
    for (let y0 = 0; y0 < h; y0 += 200) {
      const hh = Math.min(200, h - y0); out.push(0x1D, 0x76, 0x30, 0, bw & 255, bw >> 8, hh & 255, hh >> 8);
      for (let y = y0; y < y0 + hh; y++) for (let bx = 0; bx < bw; bx++) { let b = 0; for (let k = 0; k < 8; k++) { const px = bx * 8 + k; if (px < w) { const i = (y * w + px) * 4, g = (d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11); if (g < 140) b |= 0x80 >> k; } } out.push(b); }
    }
    out.push(0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x42, 0x00);
    return new Uint8Array(out);
  }
  const BLE_SVC = ['000018f0-0000-1000-8000-00805f9b34fb', '49535343-fe7d-4ae5-8fa9-9fafd205e455', 'e7810a71-73ae-499d-8c15-faa9aef0c3f2', '0000ff00-0000-1000-8000-00805f9b34fb', '0000ffe0-0000-1000-8000-00805f9b34fb'];
  let bleChar = null;
  async function bleSend(bytes) {
    if (!navigator.bluetooth) throw new Error('المتصفح لا يدعم البلوتوث — استخدم Chrome أو تطبيق الأندرويد');
    if (!bleChar || !bleChar.service.device.gatt.connected) {
      const dev = await navigator.bluetooth.requestDevice({acceptAllDevices: true, optionalServices: BLE_SVC});
      const srv = await dev.gatt.connect(); let ch = null;
      for (const sv of await srv.getPrimaryServices()) { for (const cc of await sv.getCharacteristics()) if (cc.properties.write || cc.properties.writeWithoutResponse) { ch = cc; break; } if (ch) break; }
      if (!ch) throw new Error('لم أجد قناة طباعة في هذا الجهاز');
      bleChar = ch;
    }
    for (let i = 0; i < bytes.length; i += 100) { const part = bytes.slice(i, i + 100); await (bleChar.properties.writeWithoutResponse ? bleChar.writeValueWithoutResponse(part) : bleChar.writeValue(part)); await new Promise(r => setTimeout(r, 25)); }
  }
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s); };
  Acts.receipt = async el => {
    const r = S.data.visits.find(x => x.id === el.dataset.id); if (!r) return;
    let width = +(localStorage.getItem('mc_rw') || 384); if (width !== 576) width = 384;
    const cv = await receiptCanvas(r, width);
    let printers = []; if (window.AndroidBridge && AndroidBridge.btList) { try { printers = JSON.parse(AndroidBridge.btList()); } catch (e) {} }
    const lastP = localStorage.getItem('mc_btp') || '';
    const m = modal(`<h3>🧾 إيصال ${esc(r.patient)}</h3><div style="text-align:center;background:#fff;padding:6px;border-radius:8px;max-height:55vh;overflow:auto"><img id="rimg" src="${cv.toDataURL()}" style="max-width:100%;border:1px solid #ccc"></div>
      <div class="fld"><label>عرض الورق</label><select id="rw"><option value="384" ${width === 384 ? 'selected' : ''}>58 مم</option><option value="576" ${width === 576 ? 'selected' : ''}>80 مم</option></select></div>
      ${window.AndroidBridge && AndroidBridge.btList ? `<div class="fld"><label>طابعة البلوتوث (من الأجهزة المقترنة)</label><select id="bp">${printers.length ? printers.map(p => `<option value="${esc(p.address)}" ${p.address === lastP ? 'selected' : ''}>${esc(p.name)}</option>`).join('') : '<option value="">لا توجد طابعة مقترنة — اقترنها من إعدادات بلوتوث الجهاز</option>'}</select></div>` : ''}
      <div class="actions"><button class="btn c-blue" id="rbt">🔵 طباعة بلوتوث</button><button class="btn c-gold" id="rpp">🖨️ طباعة عادية / PDF</button><button class="btn ghost" id="rcl">إغلاق</button></div>`);
    $('#rcl', m).onclick = () => m.remove();
    $('#rw', m).onchange = async e => { localStorage.setItem('mc_rw', e.target.value); const c2 = await receiptCanvas(r, +e.target.value); $('#rimg', m).src = c2.toDataURL(); };
    $('#rbt', m).onclick = e => guard(e.target, async () => {
      const bytes = escposBytes(await receiptCanvas(r, +$('#rw', m).value));
      if (window.AndroidBridge && AndroidBridge.btPrint) { const a = ($('#bp', m) || {}).value; if (!a) throw new Error('اختر طابعة مقترنة أولاً'); localStorage.setItem('mc_btp', a); const res = AndroidBridge.btPrint(a, b64(bytes)); if (res !== 'ok') throw new Error(res); }
      else await bleSend(bytes);
      toast('تمت الطباعة');
    });
    $('#rpp', m).onclick = () => {
      const css = `@page{size:80mm auto;margin:3mm}html,body{margin:0;background:#fff}img{width:74mm}`;
      m.remove(); printDoc('إيصال', '', `<img src="${$('#rimg', m).src}">`, false, {css, head: ''});
    };
  };
  Acts.print = Acts.pdf;
  window.exportButtons = '<button class="btn sm c-lime" data-act="xlsx">📗 Excel</button><button class="btn sm c-red" data-act="pdf">📄 PDF</button><button class="btn sm c-gold" data-act="pdf" title="الطباعة أو الحفظ كـ PDF">🖨️ طباعة</button>';
})();
